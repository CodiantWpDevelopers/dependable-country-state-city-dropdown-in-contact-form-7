
/* Country Ajax */
add_action('wp_ajax_ajax_country','ajax_country');
add_action('wp_ajax_nopriv_ajax_country','ajax_country');

function ajax_country(){
	global $wpdb;
	$table_name = 'countries';
	$results = $wpdb->get_results( "SELECT * FROM $table_name"); // Query to fetch data from database table and storing in $results

	$html ='';
	foreach ($results as $key => $res ){
		$html .='<option value="'.$res->name.'" data-id="'.$res->id.'">'.$res->name.'</option>';
	}
	echo $html;
	wp_die();
}

/* States Ajax */
add_action('wp_ajax_ajax_states','ajax_states');
add_action('wp_ajax_nopriv_ajax_states','ajax_states');

function ajax_states(){
	global $wpdb;
	
	$countryId = $_POST['countryId']; 
	$table_name = 'countries';
	$states = $wpdb->get_results( "SELECT * FROM bird_states WHERE countryId='$countryId'"); // Query to fetch data from database table and storing in $results
	
	$html ='';
	if(!empty($states)){
		foreach ($states as $key => $state ){
			$html .='<option value="'.$state->statename.'" data-id="'.$state->id.'">'.$state->statename.'</option>';
		}
	}else{
		$html .='<option value="-" data-id="">--</option>';
	}
	
	echo $html;
	wp_die();
}

/* Cities Ajax */
add_action('wp_ajax_ajax_city','ajax_city');
add_action('wp_ajax_nopriv_ajax_city','ajax_city');

function ajax_city(){
	global $wpdb;
	
	$stateId = $_POST['stateId']; 
	$table_name = 'countries';
	$cities = $wpdb->get_results( "SELECT * FROM bird_cities WHERE state_id='$stateId'"); // Query to fetch data from database table and storing in $results
	
	$html ='';
	if(!empty($cities)){
		foreach ($cities as $key => $city ){
			$html .='<option value="'.$city->cityName.'" data-id="'.$city->id.'">'.$city->cityName.'</option>';
		}
	}else{
		$html .='<option value="-" data-id="">--</option>';
	}
	
	echo $html;
	wp_die();
}

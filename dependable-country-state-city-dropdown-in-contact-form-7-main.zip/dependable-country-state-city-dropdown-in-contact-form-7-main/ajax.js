
/* Country Ajax Dropdown */

jQuery(document).ready(function(){
    var ajaxUrl = '<?php echo admin_url('admin-ajax.php') ?>';
    jQuery('#countryId').html('<option value="">Loading Countries... </option>');
    /* Country */
    setTimeout(function(){ 
        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data:{
                action: 'ajax_country',
            },
            success: function (response) {
                jQuery('#countryId').html(response);
            }
        });
    }, 100);

    /* States */
    $("#countryId").change(function() {
        //var countryId = $('select[name=country]').val()
        var countryId = $(this).find(':selected').attr('data-id');
        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: {
                action: 'ajax_states',
                countryId:countryId,
            },
           
            beforeSend : function ( xhr ) {
				jQuery('#stateId').html('<option value="">Loading States ... </option>');
			},

            success: function (response) {
                jQuery('#stateId').html(response);
            }
        });
    });

    /* City */
    $("#stateId").change(function() {
        //var stateId = $('select[name=state]').val()
        var stateId = $(this).find(':selected').attr('data-id');
        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: {
                action: 'ajax_city',
                stateId:stateId,
            },
            beforeSend : function ( xhr ) {
				jQuery('#cityId').html('<option value="">Loading Cities ... </option>');
			},
            success: function (response) {
                jQuery('#cityId').html(response);
            }
        });
    });


});

